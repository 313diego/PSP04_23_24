/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3.pkg1.adivinar.numero;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
/**
 *
 * @author diego
 */
public class Cliente {

    final String host = "localhost";
    final int puerto = 3000;
    String recibido;
    String adivinado = "Enhorabuena, has adivinado el número";
    Scanner sc = new Scanner(System.in);

    public Cliente() {
        try {
            Socket sCliente = new Socket(host, puerto);
            DataInputStream in = new DataInputStream(sCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(sCliente.getOutputStream());
            System.out.println("Adivina un número entre 0 y 500");
            while (true) {
                System.out.println("Introduce el número que creas");
                out.writeUTF(sc.next());
                recibido = in.readUTF();
                if (recibido.equalsIgnoreCase(adivinado)) {
                    System.out.println(adivinado);
                    sCliente.close();
                    break;
                } else {
                    System.out.println(recibido);
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());;
        }

    }

    public static void main(String[] args) {
        new Cliente();
    }

}
