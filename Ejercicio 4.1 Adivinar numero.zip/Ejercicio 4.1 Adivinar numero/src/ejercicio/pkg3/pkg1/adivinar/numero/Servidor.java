/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3.pkg1.adivinar.numero;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author diego
 */
public class Servidor extends Thread {

    static final int puerto = 3000;
    int numRecibido;
    String recibido;
    String adivinado = "Enhorabuena, has adivinado el número";
    String mayor = "El número es mayor";
    String menor = "El número es menor";
    Socket skCliente;

    public Servidor(Socket sCliente) {
        skCliente = sCliente;
    }

    public static void main(String[] args) {
        try {

            // Inicio el servidor en el puerto
            ServerSocket skServidor = new ServerSocket(puerto);
            System.out.println("Escuchando el puerto " + puerto);

            while (true) {
                // Se conecta un cliente
                Socket skCliente = skServidor.accept();
                System.out.println("Cliente conectado desde el puerto "+skCliente.getPort());
                // Atiendo al cliente mediante un thread
                new Servidor(skCliente).start();
            }
        } catch (Exception e) {;
        }
    }

    public void run() {

    try {
    final int numRandom = (int) (Math.floor(Math.random() * (500 - 0 + 1)));
    DataInputStream in = new DataInputStream(skCliente.getInputStream());
    DataOutputStream out = new DataOutputStream(skCliente.getOutputStream());

    
        while (true) {
                recibido = in.readUTF();
        System.out.println("El cliente con puerto " + skCliente.getPort() + " ha dicho " + recibido);
        numRecibido = Integer.parseInt(recibido);
        if (numRecibido == numRandom) {
            out.writeUTF(adivinado);
            skCliente.close();
            System.out.println("El cliente con puerto " + skCliente.getPort() + " se ha desconectado");
            break;
        } else if (numRecibido < numRandom) {
            out.writeUTF(mayor);
        } else {
            out.writeUTF(menor);
        }
    }
}
catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
