/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio43UsuarioyPass;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author diego
 */
public class Servidor extends Thread {

    private Socket skCliente;
    private String user = "diego";
    private String pass = "manuel";

    public Servidor(Socket sCliente) {
        skCliente = sCliente;
    }

    @Override
    public void run() {
        
        String linea;
        String documento = "";
        
        DataInputStream in = null;
        DataOutputStream out = null;
        
        try {

            in = new DataInputStream(skCliente.getInputStream());
            out = new DataOutputStream(skCliente.getOutputStream());

            out.writeUTF("Introduce el nombre de usuario (diego)");
            String userCliente = in.readUTF().trim();

            out.writeUTF("Introduce la contraseña (manuel)");
            String passCliente = in.readUTF().trim();

            if (user.equalsIgnoreCase(userCliente) && pass.equalsIgnoreCase(passCliente)) {

                System.out.println("El cliente " + skCliente.getPort() + " ha introducido "
                        + "el usuario y contraseña de forma correcta");
                out.writeBoolean(true);
                boolean salir = false;

                while (!salir) {

                    out.writeUTF("Introduce LISTAR para ver los archivos del directorio, "
                            + "\n" + "MOSTRAR para ver el contenido del archivo deseado o "
                            + "\n" + "SALIR para cerrar el programa");
                    String comando = in.readUTF().trim();

                    switch (comando.toLowerCase()) {
                        case "listar":
                            System.out.println("El cliente con puerto " + skCliente.getPort() + " desea listar el contenido del directorio actual");
                            File directorioactual = new File(System.getProperty("user.dir"));
                            File[] ficheros = directorioactual.listFiles();

                            out.writeInt(ficheros.length);

                            for (File fichero : ficheros) {
                                if (fichero.isFile()) {
                                    out.writeUTF(fichero.getName());
                                }
                            }
                            
                            out.writeUTF("FIN_LISTA_ARCHIVOS");

                            break;

                        case "mostrar":
                            String nomArchivo = in.readUTF();
                            File archivo = new File(nomArchivo);
                            System.out.println("El cliente con puerto " + skCliente.getPort()
                                    + " desea mostrar el contenido del fichero " + nomArchivo);
                            if (archivo.exists()) {
                                out.writeBoolean(true);
                                FileReader fr = new FileReader(archivo);
                                BufferedReader br = new BufferedReader(fr);
                                while ((linea = br.readLine()) != null) {
                                    documento += linea + "\n";
                                }
                                out.writeUTF(documento);
                                br.close();
                                documento = "";
                            } else {
                                out.writeBoolean(false);
                                out.writeUTF("El archivo no se ha encontrado");
                            }
                            System.out.println("Se ha mostrado el contenido del archivo " + nomArchivo
                                    + " al cliente con puerto " + skCliente.getPort());
                            break;

                        case "salir":
                            System.out.println("El cliente con puerto " + skCliente.getPort()
                                    + " se ha desconectado");
                            salir = true;
                            break;
                    }
                }

            } else {
                System.out.println("El cliente " + skCliente.getPort() + " ha introducido "
                        + "el usuario y contraseña de forma incorrecta");
                out.writeBoolean(false);
                System.out.println("El usuario con puerto " + skCliente.getPort()
                        + " se ha desconectado");
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                in.close();
                out.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
        public static void main(String[] args) {
        
        final int puerto = 4000;
        
        try {
            // Inicio el servidor en el puerto
            ServerSocket skServidor = new ServerSocket(puerto);
            System.out.println("Escuchando el puerto " + puerto);

            while (true) {
                // Se conecta un cliente
                Socket skCliente = skServidor.accept();
                System.out.println("Cliente conectado desde el puerto " + skCliente.getPort());
                // Atiendo al cliente mediante un thread
                new Servidor(skCliente).start();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
