/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio43UsuarioyPass;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author diego
 */
public class Cliente {

    final int puerto = 4000;
    final String host = "localhost";
    boolean fin;

    public Cliente() {
        try {
            Socket skCliente = new Socket(host, puerto);

            DataInputStream in = new DataInputStream(skCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(skCliente.getOutputStream());

            Scanner sc = new Scanner(System.in);
            sc.useDelimiter("\n");

            String mensaje = in.readUTF().trim();
            System.out.println(mensaje);
            String usuario = sc.next();
            out.writeUTF(usuario);

            mensaje = in.readUTF().trim();
            System.out.println(mensaje);
            String password = sc.next();
            out.writeUTF(password);

            boolean correcto = in.readBoolean();

            if (correcto) {
                
                boolean salir = false;

                while (!salir) {

                    mensaje = in.readUTF().trim();
                    System.out.println(mensaje);
                    String comando = sc.next();
                    out.writeUTF(comando);

                    switch (comando.toLowerCase()) {
                        case "listar":
                            boolean finArchivos = false;
                            while (!finArchivos) {
                                String nombreFichero = in.readUTF().trim();
                                if (nombreFichero.equals("FIN_LISTA_ARCHIVOS")) {
                                    finArchivos = true;
                                } else {
                                    System.out.println(nombreFichero);
                                }
                            }
                            break;

                        case "mostrar":  
                            try {
                            System.out.println("Introduce el nombre del archivo");
                            System.out.println("El nombre de los archivos almacenados es "
                                    + "datos.txt, info.txt, hola.txt");
                            out.writeUTF(sc.next());
                            boolean existe = in.readBoolean();
                            if (existe) {
                                System.out.println(in.readUTF());
                            } else {
                                System.out.println("El archivo no existe.");
                            }
                            break;
                        } catch (IOException ex) {
                            System.out.println(ex.getMessage());
                        }

                        break;

                        case "salir":
                            System.out.println("El programa se va a cerrar");
                            salir = true;
                            break;
                    }
                }
            } else {
                System.out.println("Usuario o password incorrectos");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new Cliente();
    }
}
