/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3.pkg2.enviar.fichero;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author diego
 */
public class Servidor extends Thread{
    static final int puerto = 4000;
    String nomFichero;
    String mensaje = "El fichero mencionado no existe";
    String linea;
    String documento = "";
    Socket skCliente;

    public Servidor(Socket sCliente) {
        skCliente = sCliente;
    }
    
    public static void main(String[] args) {
        
        try {

            // Inicio el servidor en el puerto
            ServerSocket skServidor = new ServerSocket(puerto);
            System.out.println("Escuchando el puerto " + puerto);

            while (true) {
                // Se conecta un cliente
                Socket skCliente = skServidor.accept();
                System.out.println("Cliente conectado desde el puerto "+skCliente.getPort());
                // Atiendo al cliente mediante un thread
                new Servidor(skCliente).start();
            }
        } catch (Exception e) {;
        }
        
    }

    @Override
    public void run() {
        try {
            DataInputStream in = new DataInputStream(skCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(skCliente.getOutputStream());
            nomFichero = in.readUTF();
            System.out.println("El cliente con puerto " + skCliente.getPort() +
                    " desea leer el ficher " + nomFichero);
            File fichero = new File(nomFichero);
            if (fichero.exists()) {
                out.writeBoolean(true);
                FileReader fr = new FileReader(fichero);
                BufferedReader br = new BufferedReader(fr);
                while ((linea = br.readLine()) != null) {
                    //System.out.println(linea);
                    documento += linea + "\n";
                }
                out.writeUTF(documento);
                skCliente.close();
                br.close();
                System.out.println("El fichero se ha enviado correctamente al cliente "
                        + "con puerto " + skCliente.getPort());
                System.out.println("El ciente con puerto " + skCliente.getPort() + 
                        " se ha desconectado");
            } else {
                out.writeBoolean(false);
                out.writeUTF(mensaje);
                System.out.println("El ciente con puerto " + skCliente.getPort() +
                        " se ha desconectado");
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    
    
}
