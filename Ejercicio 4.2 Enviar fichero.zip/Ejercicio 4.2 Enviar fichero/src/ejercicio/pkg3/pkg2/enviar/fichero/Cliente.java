/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3.pkg2.enviar.fichero;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author diego
 */
public class Cliente {

    final int puerto = 4000;
    final String host = "localhost";
    boolean existe;
    Scanner sc = new Scanner(System.in);

    public Cliente() {
        try {
            Socket sCliente = new Socket(host, puerto);
            DataInputStream in = new DataInputStream(sCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(sCliente.getOutputStream());
            System.out.println("Introduce el nombre del fichero");
            System.out.println("El nombre del fichero almacenado es datos.txt");
            while (true) {
                out.writeUTF(sc.next());
                existe = in.readBoolean();
                if (existe) {
                    System.out.println(in.readUTF());
                    sCliente.close();
                } else {
                    System.out.println(in.readUTF());
                    sCliente.close();
                }
                break;
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Cliente();
    }

}
